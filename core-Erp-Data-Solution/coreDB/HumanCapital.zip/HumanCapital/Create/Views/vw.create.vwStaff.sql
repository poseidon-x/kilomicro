﻿use coreDB
go

create view hc.vwStaff
with encryption as
select
	staffID,
	surName + ', ' + otherNames + ' (' + staffNo + ')' as staffName,
	staffNo,
	surName,
	otherNames
from fa.staff

go

