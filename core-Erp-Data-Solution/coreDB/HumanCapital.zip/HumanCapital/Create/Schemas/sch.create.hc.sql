﻿use coreDB
go

create schema hc
go
